# Sample Page

This is a second page to act as a way of showing of routing and layouts.

[Home](/)