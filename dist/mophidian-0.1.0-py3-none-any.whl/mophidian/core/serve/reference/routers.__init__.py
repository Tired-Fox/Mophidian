def GET(handler):
  return "OK"